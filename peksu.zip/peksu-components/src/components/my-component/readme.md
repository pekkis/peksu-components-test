# my-component



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description     | Type     | Default        |
| -------- | --------- | --------------- | -------- | -------------- |
| `first`  | `first`   | The first name  | `string` | `'Pekkis'`     |
| `last`   | `last`    | The last name   | `string` | `'Pierupöksy'` |
| `middle` | `middle`  | The middle name | `string` | `'Johtaja'`    |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
